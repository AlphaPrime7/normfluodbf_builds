#' @importFrom tibble tibble
NULL

#' liposomes_214.
#'
#' FLUOstar .dbf file in wide format and unable to use for data analysis.
#'
#'
"liposomes_214"

#' liposomes_215.
#'
#' FLUOstar .dbf file in wide format and unable to use for data analysis.
#'
#'
"liposomes_215"

#' liposomes_216.
#'
#' FLUOstar .dbf file in wide format and unable to use for data analysis.
#'
#'
"liposomes_216"

#' liposomes_218.
#'
#' FLUOstar .dbf file in wide format and unable to use for data analysis.
#'
#'
"liposomes_218"

#' liposomes_221.
#'
#' FLUOstar .dbf file in wide format and unable to use for data analysis.
#'
#'
"liposomes_221"

#' liposomes_227.
#'
#' FLUOstar .dbf file in wide format and unable to use for data analysis.
#'
#'
"liposomes_227"

#' dat_1.
#'
#' FLUOstar .dat files used for creation of the update and unusable for data immediate data analysis.
#'
#'
"dat_1"

#' dat_2.
#'
#' FLUOstar .dat files used for creation of the update and unusable for data immediate data analysis.
#'
#'
"dat_2"

#' dat_3.
#'
#' FLUOstar .dat files used for creation of the update and unusable for data immediate data analysis. 
#' This file is unique because it validates a major bug fix to ensure that users get the right output.
#'
"dat_3"

