# normfluodbf 1.4.1

# normfluodbf 1.4

# normfluodbf 1.3

# normfluodbf 1.2

# normfluodbf 1.1

# normfluodbf 1.0

-   First version of the package. Been an experience working on this.

-   Initial CRAN submission.
