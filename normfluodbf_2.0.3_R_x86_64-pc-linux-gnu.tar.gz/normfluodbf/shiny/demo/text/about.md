## Intro

A quick demo of the normfluodbf Shiny App.

## Quick overview

This app demo really just allows users to download the data as a csv and use it in Excel.

As i work on the demo which is a re-factorization of the initial shiny app I built as a jar head, I will find out other cool features that can be added.

Select the **<i class="fa fa-table"></i> Import Assay Data** to import a .dbf or .dat file from a liposome flux assay.

Select the **<i class="fa fa-magnifying-glass"></i> Preview Data** tab Preview the raw or normalized data.

Select the **<i class="fa fa-chart-simple"></i> Plot Wells** tab to do some plotting (if possible).

## More information

This project is part of my mastering shiny endeavor.

Report bugs to Me.

## Epilogue

Dont ask me anything. Enjoy the App!
