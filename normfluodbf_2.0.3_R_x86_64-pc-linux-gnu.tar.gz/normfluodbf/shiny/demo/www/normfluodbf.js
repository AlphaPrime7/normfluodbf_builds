var normfluodbf = {
  init : function() {
    $("[data-toggle='popover']").popover();
  }
};

document.addEventListener('DOMContentLoaded', normfluodbf.init);
