# normfluodbf 1.5.2

- This is the most mature release and all bugs have been squashed with this release. Only considerations for the next update is to account for machine corruption that could yield very weird files that will need more User control. I will do my best to make updates if changes to the programs' dependencies occur. THANKS to a R and the community of scientists that will be part of normfluodbf.

# normfluodbf 1.5.1

- This release takes care of a major bug found in the program which was discovered about 2 days after release. The issue with resampling data that contains a single column when the read direction is horizontal. I tested the program after release and noticed this issue and promptly addressed it.

# normfluodbf 1.5.0

- An update to handle DAT files.

# normfluodbf 1.4.3.9000 - Latest Pre-release of the Update

- This developmental version was a lot of hardwork that gave users the option of analyzing DAT files.

# normfluodbf 1.4.3

- This was the final program for the first release of this program. This version was ONLY able to handle DBF files. 

# normfluodbf 1.4.2

- Pre-release to version 1.4.3. Revisions with CRAN led to 1.4.3.

# normfluodbf 1.4.1

- Pre-release to version 1.4.3. Revisions with CRAN led to 1.4.3.

# normfluodbf 1.4

- Pre-release to version 1.4.3. Revisions with CRAN led to 1.4.3.

# normfluodbf 1.3

- Pre-release to version 1.4.3. Revisions with CRAN led to 1.4.3.

# normfluodbf 1.2

- Pre-release to version 1.4.3. Revisions with CRAN led to 1.4.3.

# normfluodbf 1.1

- Pre-release to version 1.4.3. Revisions with CRAN led to 1.4.3.

# normfluodbf 1.0

- Pre-release to version 1.4.3. Revisions with CRAN led to 1.4.3.
