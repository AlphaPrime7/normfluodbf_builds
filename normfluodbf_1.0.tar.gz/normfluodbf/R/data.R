#' @importFrom tibble tibble
NULL

#' liposomes_214.
#'
#' FLUOstar .dbf file in wide format and unable to use to data analysis.
#'
#'
"liposomes_214"

#' liposomes_215.
#'
#' FLUOstar .dbf file in wide format and unable to use to data analysis.
#'
#'
"liposomes_215"

#' liposomes_216.
#'
#' FLUOstar .dbf file in wide format and unable to use to data analysis.
#'
#'
"liposomes_216"

#' liposomes_218.
#'
#' FLUOstar .dbf file in wide format and unable to use to data analysis.
#'
#'
"liposomes_218"

#' liposomes_221.
#'
#' FLUOstar .dbf file in wide format and unable to use to data analysis.
#'
#'
"liposomes_221"

#' liposomes_227.
#'
#' FLUOstar .dbf file in wide format and unable to use to data analysis.
#'
#'
"liposomes_227"
