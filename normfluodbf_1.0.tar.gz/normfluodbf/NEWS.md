# normfluodbf 1.0

-   First version of the package. Been an experience working on this.

-   Initial CRAN submission.
